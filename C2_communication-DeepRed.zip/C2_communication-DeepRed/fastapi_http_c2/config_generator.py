"""
This file is for generatinge configurations that describe the communication including
1) 
"""
import json, random
class config_generator():
    def __init__(self, number_of_configs:int):
        self.total_number_of_beacon = random.randint(300,1000)
        self.beacon_iat = random.randint(2, 7)
