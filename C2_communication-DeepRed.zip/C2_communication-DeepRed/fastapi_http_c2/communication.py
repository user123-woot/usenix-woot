"""
testing different design pattern, for implemtation however, according to the requirements we decided to use factory using websocket
"""
import time
import threading
import random
import requests
from http.server import SimpleHTTPRequestHandler, HTTPServer
from datetime import datetime

class CommunicationStage:
    def __init__(self, stage_name, parameters):
        self.stage_name = stage_name
        self.parameters = parameters  # Attributes or parameters for the stage

        
    def execute(self):
        """This method is to be implemented by subclasses"""
        raise NotImplementedError("Each stage must implement the 'execute' method.")
    
    def get_stage_info(self):
        """General information about the stage."""
        return f"Stage: {self.stage_name}, Parameters: {self.parameters}"
    

    @property
    def src2dst_packets(self):
        """Getter for src2dst_packets."""
        return self._src2dst_packets
    
    @src2dst_packets.setter
    def src2dst_packets(self, number_of_packets):
        """Setter for src2dst_packets."""
        if number_of_packets >= 0:  # Optional: validation can go here
            self._src2dst_packets = number_of_packets
        else:
            raise ValueError("Number of packets must be non-negative.")

a = CommunicationStage("beacon", None)
a.src2dst_packets= 10

print(a.src2dst_packets)


class ClientStage(CommunicationStage):
    def __init__(self, parameters, server_url):
        super().__init__('Client', parameters)
        self.server_url = server_url  # Server address for communication

    def send_beacon(self):
        """Send periodic GET request to server."""
        response = requests.get(self.server_url, params={'client_id': self.parameters['client_id']})
        if response.status_code == 200:
            print(f"Beacon sent successfully. Server response: {response.text}")
            return response.text
        else:
            print(f"Error sending beacon to server.")
            return None

    def execute_command(self, command):
        """Execute the command received from the server."""
        print(f"Executing command: {command}")
        try:
            # This is where we would execute the actual command
            result = "Command output: " + command  # Example response
            return result
        except Exception as e:
            return f"Error executing command: {str(e)}"

    def post_result(self, result):
        """Send the result back to the server."""
        response = requests.post(self.server_url, json={'client_id': self.parameters['client_id'], 'result': result})
        if response.status_code == 200:
            print(f"Result posted successfully.")
        else:
            print(f"Error posting result to server.")

    def execute(self):
        """Handle client beaconing and posting results."""
        while True:
            # Send beacon
            command = self.send_beacon()

            # If command received, execute it
            if command:
                result = self.execute_command(command)

                # Send back the result
                self.post_result(result)

            # Sleep for the defined interval (IAE)
            time.sleep(self.parameters['beacon_interval'])

"""
class CommunicationStage:
    def __init__(self, stage_name, parameters):
        self.stage_name = stage_name  # Name of the stage (e.g., 'initial', 'processing', 'final')
        self.parameters = parameters  # Attributes or parameters for the stage (e.g., {'timeout': 30, 'retry': 3})

    def execute(self):
        raise NotImplementedError("Each stage must implement the 'execute' method.")
    
    def get_stage_info(self):
        return f"Stage: {self.stage_name}, Parameters: {self.parameters}"
    
class InitialStage(CommunicationStage):
    def __init__(self, parameters):
        super().__init__('Initial', parameters)

    def execute(self):
        # Implement the logic for the initial stage of communication
        print(f"Executing {self.stage_name} stage with parameters {self.parameters}")
        # Example: Initialize connections or configurations
        # You could use self.parameters here to adjust how the stage behaves.
        return "Initial stage completed"


class ProcessingStage(CommunicationStage):
    def __init__(self, parameters):
        super().__init__('Processing', parameters)

    def execute(self):
        # Implement the processing stage of communication
        print(f"Executing {self.stage_name} stage with parameters {self.parameters}")
        # Example: Process data or request
        return "Processing stage completed"


class FinalStage(CommunicationStage):
    def __init__(self, parameters):
        super().__init__('Final', parameters)

    def execute(self):
        # Implement the final stage of communication
        print(f"Executing {self.stage_name} stage with parameters {self.parameters}")
        # Example: Complete communication and close connections
        return "Final stage completed"
    
class CommunicationProcess:
    def __init__(self, stages):
        self.stages = stages  # List of communication stages

    def run(self):
        for stage in self.stages:
            print(stage.get_stage_info())  # Optionally log or print information about each stage
            result = stage.execute()
            print(f"Result of {stage.stage_name} stage: {result}")

def main():
    # Set up parameters for each stage
    initial_params = {'timeout': 30, 'retry': 3}
    processing_params = {'data_size': 'large', 'compression': 'enabled'}
    final_params = {'confirmation': 'required'}

    # Instantiate each stage
    initial_stage = InitialStage(initial_params)
    processing_stage = ProcessingStage(processing_params)
    final_stage = FinalStage(final_params)

    # Create a communication process and run it
    communication_process = CommunicationProcess([initial_stage, processing_stage, final_stage])
    communication_process.run()

if __name__ == "__main__":
    main()
    """