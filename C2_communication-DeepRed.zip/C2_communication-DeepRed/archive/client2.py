import requests
import random

def send_packet_to_server(packet_data):
    server_url = 'http://localhost:5000/api/send_packet'
    response = requests.post(server_url, data=packet_data)
    return response.json()

def generate_packets(num_packets, max_packet_size, min_packet_size):
    packets = []
    for _ in range(num_packets):
        packet_size = random.randint(min_packet_size, max_packet_size)
        packet_data = b"X" * packet_size  # Generating arbitrary packet data
        packets.append(packet_data)
    return packets

if __name__ == '__main__':
    num_packets = 10
    max_packet_size = 1024
    min_packet_size = 512

    packets = generate_packets(num_packets, max_packet_size, min_packet_size)

    for idx, packet in enumerate(packets):
        response = send_packet_to_server(packet)
        print(f"Packet {idx + 1}/{num_packets} sent: {response}")

