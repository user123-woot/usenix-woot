import requests
import pickle, yaml, os

class bot:
    def __init__(self, addr:str,name:str,ip:str = '127.0.0.1', port:str='5000'):
        self.c2_url= 'http://'+ ip +':'+port+'/api/'
        with open(addr, 'r') as f:
            self.config = yaml.safe_load(f)
        self.name = name

    def add_capabilities(self, capability):
        pass

    def short_beacon (self, data):
        server_api = self.c2_url +'short_beacon'
        response = requests.post(server_api, data=data)
        return response.json()

if __name__ == '__main__':
    """ packet = "I'm alive"
    response = short_beacon(packet)
    print(response)"""
