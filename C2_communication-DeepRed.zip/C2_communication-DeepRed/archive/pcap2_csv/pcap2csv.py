from nfstream import NFStreamer
import nfstream
import time
import scapy.all as scapy

def extract_flows(packets):
    flows = []
    for packet in packets:
        flow = scapy.get_conversation(packet)
        if flow is not None:
            flows.append(flow)
    return flows

# Capture packets on the mirror port
packets = scapy.sniff(iface="lo")

# Extract flows from the captured packets
flows = extract_flows(packets)

"""flow_list = []

my_streamer = NFStreamer(source="lo",
                         # Disable L7 dissection for readability purpose.
                         n_dissections=0,
                         statistical_analysis=True,
                         active_timeout = 10
                         #idle_timeout=2,
                         #system_visibility_poll_ms=0
                         )

print('before loop ', time.strftime("%H:%M:%S"))
#time.sleep(1)
for flow in my_streamer:
    print( 'inside loop:' ,  time.strftime("%H:%M:%S"))

    print((flow))

#print(flow_list, len(flow_list))
#ds= my_streamer.to_pandas()
#print("http_beaconig_9_bots_mehrdad.csv Shape: {}".format(ds.shape))
#ds.to_csv('/media/sf_GAN_output/red-teaming-10-Sep-2023/4.comparison_with_CICIDSandUNSW/New DS/http_beaconig_9_bots_and_cmd.csv',index=False)
"""