import requests

def short_beacon (data):
    server_url = 'http://localhost:5000/api/short_beacon'
    response = requests.post(server_url, data=data)
    return response.json()
def ping():
    try:
        server_url = 'http://localhost:5000/api/ping'
        response = requests.get(server_url)
        return response.status_code == 200 and response.text == 'pong'

    except requests.exceptions.RequestException:
        return False

if __name__ == '__main__':
    packet = "I'm alive"
    #response = short_beacon(packet)
    #print(response)
    while True:
        if ping():
            print("Connection is alive")
        else:
            print("Connection is lost")