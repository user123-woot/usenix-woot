from flask import Flask, request, jsonify, make_response, Response
import threading
import time

app = Flask(__name__)

# Flag to indicate if new data is available
new_data_flag = False

@app.route('/poll', methods=['GET'])
def poll():
    global new_data_flag

    # This is a long-polling request
    while not new_data_flag:
        time.sleep(1)  # Simulate waiting for new data

    Response('Hello')
    new_data_flag = False  # Reset the flag after data is sent

    return 'New data is available!'

# Function to simulate new data becoming available
def simulate_new_data():
    global new_data_flag
    while True:
    # Simulate new data being available after some time
        time.sleep(5)
        new_data_flag = True

if __name__ == '__main__':
    new_data_flag = False

    # Simulate new data becoming available in a separate thread
    threading.Thread(target=simulate_new_data).start()

    # Start the Flask app
    app.run(host='localhost', port=8000)


"""
# Long polling involves sending a request to the server and keeping the connection open until the server has new data to send
from http.server import BaseHTTPRequestHandler, HTTPServer
import time

class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/get_beacon':
            # Simulate long polling by waiting for 5 seconds
            #while True:
            time.sleep(5)
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            #while True:
            self.wfile.write(b'C2 is ready\n')

    def do_POST(self):
        if self.path == '/send_file':
            content_length = int(self.headers['Content-Length'])
            file_content = self.rfile.read(content_length)

            # Save the received file to a server directory
            with open('victim/received_file_long_pooling.txt', 'wb') as file:
                file.write(file_content)

            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b'File received by server')

if __name__ == '__main__':
    server_address = ('', 8080)
    httpd = HTTPServer(server_address, MyHandler)
    print('Server started on port 8080...')
    httpd.serve_forever()

"""
"""
class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/plain')
        self.end_headers()
        while True:
            
            self.wfile.write(b'Hello, world!\n')
            time.sleep(10)
    def do_POST(self):
        data = request.data
server = HTTPServer(('localhost', 8080), MyHandler)
server.serve_forever()
"""