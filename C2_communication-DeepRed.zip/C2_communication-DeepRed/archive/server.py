from flask import Flask, request, jsonify
#from scapy.all import  IP, UDP, Raw, send

app = Flask(__name__)

@app.route('/api/short_beacon', methods=['POST'])
def beacon_ack():
    data = request.data
    destination_ip = '127.0.0.1'  # Replace with actual destination IP

    print(data)
    #packet = IP(dst=destination_ip) / UDP(dport=12345) / Raw(load=packet_data)
    #send(packet)

    return jsonify({"message": "Beacon received"})

@app.route('/api/ping', methods=['POST'])
def ping():
    return 'pong'

if __name__ == '__main__':
    app.run(debug=True)
