try:
    with open('/home/mehrdad/PycharmProjects/C2_communication/file_test.txt', 'rb') as file:
        while True:
            chunk = file.read(1024)
            if not chunk:
                file.close()
                break
            with open('a.abc', 'wb') as wfile:
                while True:
                    data = chunk
                    if not data:
                        wfile.close()
                        break
                    wfile.write(data)
                    chunk=''

except:
    print("File transfer error")
