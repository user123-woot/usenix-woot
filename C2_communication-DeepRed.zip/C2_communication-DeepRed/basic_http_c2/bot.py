
"""
This code is written on 5.2.2025 where use basic http.sever for communications.
The main important feature is that the connection goes over single TCP connection similar to other C2.
In its doc it is mentioned that http.sever is not suit for production and that is why I code the other one with fastapi.
"""
import requests
import time

URL = "http://localhost:5000/status"
INTERVAL = 5  # Time in seconds between requests

def send_periodic_requests():
    with requests.Session() as session:  # Use persistent session
        while True:
            try:
                response = session.get(URL, headers={'Connection': 'keep-alive'}, timeout=10)
                if response.status_code == 200:
                    print(f"Received: {response.json()}")
                else:
                    print(f"Error: {response.status_code}")
            except requests.RequestException as e:
                print(f"Request failed: {e}")
            time.sleep(INTERVAL)  # Wait before the next request

if __name__ == "__main__":
    send_periodic_requests()

