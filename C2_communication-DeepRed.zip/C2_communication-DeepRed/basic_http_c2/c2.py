"""
This code is written on 5.2.2025 where use basic http.sever for communications.
The main important feature is that the connection goes over single TCP connection similar to other C2.
In its doc it is mentioned that http.sever is not suit for production and that is why I code the other one with fastapi.
"""
from http.server import BaseHTTPRequestHandler, HTTPServer
import time
import logging
import json
from http import HTTPStatus

logging.basicConfig(level=logging.DEBUG, format='- [%(asctime)s] - %(message)s')

hostName = "localhost"
serverPort = 5000

class MyServer(BaseHTTPRequestHandler):
    def _set_response(self, status=HTTPStatus.OK, content_length=0):
        self.send_response(status)
        self.send_header("Content-type", "application/json")
        self.send_header("Connection", "keep-alive")
        self.send_header("keep-alive", "timeout=5, max=30")
        self.send_header("Content-length", str(content_length))
        self.end_headers()

    def do_GET(self):
        if self.path == "/status":
            response_content = json.dumps({"status": "Server is running"})
        elif self.path == "/data":
            response_content = json.dumps({"data": [1, 2, 3, 4]})
        else:
            self._set_response(HTTPStatus.NOT_FOUND)
            return

        self._set_response(content_length=len(response_content))
        self.wfile.write(response_content.encode('utf-8'))

    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        post_data = self.rfile.read(content_length).decode('utf-8')

        if self.path == "/submit":
            data = json.loads(post_data)
            response_content = json.dumps({"received": data})
        elif self.path == "/upload":
            response_content = json.dumps({"message": "File upload received"})
        else:
            self._set_response(HTTPStatus.NOT_FOUND)
            return

        self._set_response(content_length=len(response_content))
        self.wfile.write(response_content.encode('utf-8'))
        logging.debug(f'POST {self.path} - Data: {post_data}')

if __name__ == "__main__":        
    webServer = HTTPServer((hostName, serverPort), MyServer)
    logging.info("Server started http://%s:%s" % (hostName, serverPort))

    try:
        webServer.serve_forever()
    except KeyboardInterrupt:
        pass

    webServer.server_close()
    logging.info("Server stopped.")
    