1.3.2025

File: c2-bot-deepred-28-2-2025-002.csv
Shape: (595, 77)
File: c2-bot-deepred-28-2-2025.csv
Shape: (1129, 77)
File: c2-bot-deepred-27-2-2025.csv
Shape: (1132, 77)
File: c2-bot-deepred-28-2-2025-001.csv
Shape: (1964, 77)
File: c2-bot-deepred-1-3-2025-000.csv
Shape: (3607, 77)
File: c2-bot-deepred-28-2-2025-004.csv
Shape: (4388, 77)

total: 12815